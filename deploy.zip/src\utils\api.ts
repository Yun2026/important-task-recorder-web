// API接口配置
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://119.29.132.22:3001'

// 获取token
const getToken = () => localStorage.getItem('token')

// 通用请求封装
async function request<T>(url: string, options: RequestInit = {}): Promise<{ success: boolean; data?: T; msg?: string }> {
  const token = getToken()
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  }
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  try {
    const response = await fetch(`${API_BASE_URL}${url}`, {
      ...options,
      headers
    })
    
    const result = await response.json()
    
    if (result.code === 200 || result.code === 201) {
      return { success: true, data: result.data, msg: result.msg }
    } else {
      return { success: false, msg: result.msg || '请求失败' }
    }
  } catch (error) {
    console.error('API请求失败:', error)
    return { success: false, msg: '网络请求失败' }
  }
}

// 用户认证相关API
export const authApi = {
  // 注册
  register: (data: { nickname: string; email: string; password: string; confirmPassword: string }) => 
    request('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data)
    }),
  
  // 登录
  login: (data: { email: string; password: string }) => 
    request<{ token: string; userInfo: { userId: number; nickname: string; email: string } }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(data)
    }),
  
  // 获取当前用户信息
  getCurrentUser: () => 
    request<{ id: number; nickname: string; email: string; create_time: string }>('/api/auth/me', {
      method: 'GET'
    })
}

// 事务相关API
export interface TaskData {
  id?: number
  user_id?: number
  title: string
  content?: string
  start_time?: string
  end_time?: string
  priority?: 'high' | 'medium' | 'low'
  tags?: string
  is_completed?: number
  create_time?: string
  update_time?: string
  reminder_enabled?: number
  reminder_time?: string
}

export const taskApi = {
  // 获取所有事务
  getAll: () => request<TaskData[]>('/api/tasks', { method: 'GET' }),
  
  // 添加事务
  create: (data: Partial<TaskData>) => 
    request<TaskData>('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(data)
    }),
  
  // 更新事务
  update: (id: number, data: Partial<TaskData>) => 
    request<TaskData>(`/api/tasks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    }),
  
  // 更新完成状态
  toggleComplete: (id: number, isCompleted: boolean) => 
    request<TaskData>(`/api/tasks/${id}/complete`, {
      method: 'PUT',
      body: JSON.stringify({ is_completed: isCompleted })
    }),
  
  // 删除事务
  delete: (id: number) => 
    request(`/api/tasks/${id}`, { method: 'DELETE' }),
  
  // 清除已完成事务
  clearCompleted: () => 
    request('/api/tasks/clear-completed', { method: 'DELETE' })
}

// 回收站相关API（预留）
export const recycleBinApi = {
  getAll: () => Promise.resolve({ success: true, data: [] }),
  restore: (_id: string) => Promise.resolve({ success: true }),
  permanentDelete: (_id: string) => Promise.resolve({ success: true }),
  clear: () => Promise.resolve({ success: true })
}
