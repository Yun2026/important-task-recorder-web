import { createApp } from 'vue'
import App from './App.vue'
import './style/global.css'

createApp(App).mount('#app')
