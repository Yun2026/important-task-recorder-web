// 统一导出存储模块
export { cloudStorage, storage, setSyncStatusCallback } from './cloudStorage'
export { app, db, anonymousLogin, checkLoginStatus, getOpenId } from './cloudbase'
