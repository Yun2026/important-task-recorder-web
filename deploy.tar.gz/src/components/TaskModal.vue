<script setup lang="ts">
import { ref, watch, computed } from 'vue'
import { Task, Priority, Category, ModalType, Reminder, TaskStatus } from '@/types'
import { generateUUID, formatDate, formatDateTime } from '@/utils/tools'

interface Props {
  visible: boolean
  type: ModalType
  editTask?: Task
}

const props = defineProps<Props>()

const emit = defineEmits<{
  (e: 'close'): void
  (e: 'save', task: Task): void
}>()

// 获取北京时间（UTC+8）
const getBeijingTime = () => {
  const now = new Date()
  const utc = now.getTime() + (now.getTimezoneOffset() * 60000)
  return new Date(utc + (3600000 * 8))
}

// 生成小时选项（0-23）
const hourOptions = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'))
// 生成分钟选项（0-59）
const minuteOptions = Array.from({ length: 60 }, (_, i) => i.toString().padStart(2, '0'))

const form = ref({
  title: '',
  subTitle: '',
  priority: Priority.MID,
  category: Category.WORK,
  startDate: '',
  startHour: '09',
  startMinute: '00',
  startSecond: '00',
  endDate: '',
  endHour: '18',
  endMinute: '00',
  tags: '',
  reminderEnabled: false,
  reminderDate: '',
  reminderHour: '09',
  reminderMinute: '00',
  reminderSecond: '00'
})

// 计算当前北京时间
const beijingNow = computed(() => getBeijingTime())
const currentBeijingDate = computed(() => formatDate(beijingNow.value))
const currentBeijingHour = computed(() => beijingNow.value.getHours())
const currentBeijingMinute = computed(() => beijingNow.value.getMinutes())
const currentBeijingSecond = computed(() => beijingNow.value.getSeconds())

// 开始日期和时间无限制，可以任意选择

// 校验结束日期是否有效（不能早于开始日期）
const isEndDateValid = computed(() => {
  if (!form.value.endDate || !form.value.startDate) return true
  return form.value.endDate >= form.value.startDate
})

// 校验结束时间是否有效（如果是同一天，不能早于开始时间）
const isEndTimeValid = computed(() => {
  if (!form.value.endDate || !form.value.startDate) return true
  if (form.value.endDate > form.value.startDate) return true
  // 是同一天，检查时间
  const endHour = parseInt(form.value.endHour)
  const startHour = parseInt(form.value.startHour)
  if (endHour > startHour) return true
  if (endHour < startHour) return false
  return parseInt(form.value.endMinute) >= parseInt(form.value.startMinute)
})

// 校验提醒日期是否有效（精确到秒）
const isReminderDateValid = computed(() => {
  if (!form.value.reminderEnabled || !form.value.reminderDate) return true

  // 构建完整的日期时间对象进行比较（精确到秒）
  const startDateTime = new Date(`${form.value.startDate}T${form.value.startHour}:${form.value.startMinute}:${form.value.startSecond || '00'}`)
  const reminderDateTime = new Date(`${form.value.reminderDate}T${form.value.reminderHour}:${form.value.reminderMinute}:${form.value.reminderSecond || '00'}`)
  const now = getBeijingTime()

  // 规则1: 提醒时间必须 ≤ 开始时间（禁止晚于开始时间）
  if (reminderDateTime > startDateTime) return false

  // 规则2: 提醒时间不能早于开始时间前30天
  const thirtyDaysBeforeStart = new Date(startDateTime)
  thirtyDaysBeforeStart.setDate(thirtyDaysBeforeStart.getDate() - 30)
  if (reminderDateTime < thirtyDaysBeforeStart) return false

  // 规则3: 提醒时间不能是过去的时间
  if (reminderDateTime < now) return false

  return true
})

// 校验提醒时间是否有效（精确到秒）
const isReminderTimeValid = computed(() => {
  if (!form.value.reminderEnabled || !form.value.reminderDate) return true

  // 构建完整的日期时间对象进行比较（精确到秒）
  const startDateTime = new Date(`${form.value.startDate}T${form.value.startHour}:${form.value.startMinute}:${form.value.startSecond || '00'}`)
  const reminderDateTime = new Date(`${form.value.reminderDate}T${form.value.reminderHour}:${form.value.reminderMinute}:${form.value.reminderSecond || '00'}`)
  const now = getBeijingTime()

  // 规则1: 提醒时间必须 ≤ 开始时间
  if (reminderDateTime > startDateTime) return false

  // 规则2: 提醒时间不能是过去的时间
  if (reminderDateTime < now) return false

  return true
})

// 判断日期是否可选择（用于日期选择器）
// const isDateSelectable = (date: string) => {
//   return date >= currentBeijingDate.value
// }

// 判断小时是否可选择（结束时间，开始日期当天）
const isEndHourSelectable = (hour: string) => {
  if (form.value.endDate > form.value.startDate) return true
  return parseInt(hour) >= parseInt(form.value.startHour)
}

// 判断分钟是否可选择（结束时间，开始日期当天当前小时）
const isEndMinuteSelectable = (minute: string) => {
  if (form.value.endDate > form.value.startDate) return true
  if (parseInt(form.value.endHour) > parseInt(form.value.startHour)) return true
  if (parseInt(form.value.endHour) < parseInt(form.value.startHour)) return false
  return parseInt(minute) >= parseInt(form.value.startMinute)
}

// 判断小时是否可选择（提醒时间）- 基于完整时间戳
const isReminderHourSelectable = (hour: string) => {
  // 构建测试时间（使用当前选中的分钟和秒）
  const startDateTime = new Date(`${form.value.startDate}T${form.value.startHour}:${form.value.startMinute}:${form.value.startSecond || '00'}`)
  const testReminderTime = new Date(`${form.value.reminderDate}T${hour}:${form.value.reminderMinute}:${form.value.reminderSecond || '00'}`)
  const now = getBeijingTime()

  // 检查30天限制
  const thirtyDaysBeforeStart = new Date(startDateTime)
  thirtyDaysBeforeStart.setDate(thirtyDaysBeforeStart.getDate() - 30)

  // 如果测试时间晚于开始时间，禁止选择
  if (testReminderTime > startDateTime) return false

  // 如果测试时间早于30天前，禁止选择
  if (testReminderTime < thirtyDaysBeforeStart) return false

  // 如果测试时间早于当前时间，禁止选择
  if (testReminderTime < now) return false

  return true
}

// 判断分钟是否可选择（提醒时间）- 基于完整时间戳
const isReminderMinuteSelectable = (minute: string) => {
  // 构建测试时间（使用当前选中的小时和秒）
  const startDateTime = new Date(`${form.value.startDate}T${form.value.startHour}:${form.value.startMinute}:${form.value.startSecond || '00'}`)
  const testReminderTime = new Date(`${form.value.reminderDate}T${form.value.reminderHour}:${minute}:${form.value.reminderSecond || '00'}`)
  const now = getBeijingTime()

  // 检查30天限制
  const thirtyDaysBeforeStart = new Date(startDateTime)
  thirtyDaysBeforeStart.setDate(thirtyDaysBeforeStart.getDate() - 30)

  // 如果测试时间晚于开始时间，禁止选择
  if (testReminderTime > startDateTime) return false

  // 如果测试时间早于30天前，禁止选择
  if (testReminderTime < thirtyDaysBeforeStart) return false

  // 如果测试时间早于当前时间，禁止选择
  if (testReminderTime < now) return false

  return true
}

const resetForm = () => {
  const today = currentBeijingDate.value
  const currentHour = currentBeijingHour.value.toString().padStart(2, '0')
  const currentMinute = currentBeijingMinute.value.toString().padStart(2, '0')
  const currentSecond = currentBeijingSecond.value.toString().padStart(2, '0')
  form.value = {
    title: '',
    subTitle: '',
    priority: Priority.MID,
    category: Category.WORK,
    startDate: today,
    startHour: currentHour,
    startMinute: currentMinute,
    startSecond: currentSecond,
    endDate: today,
    endHour: '18',
    endMinute: '00',
    tags: '',
    reminderEnabled: false,
    reminderDate: today,
    reminderHour: currentHour,
    reminderMinute: currentMinute,
    reminderSecond: currentSecond
  }
}

const loadEditData = () => {
  if (props.editTask) {
    const reminder = props.editTask.reminder
    // 解析截止日期和时间
    const deadlineParts = props.editTask.deadline.split(' ')
    const endDate = deadlineParts[0]
    const endTime = deadlineParts[1] || '18:00'
    const [endHour, endMinute] = endTime.split(':')

    // 解析提醒时间（兼容旧数据，可能没有秒）
    let reminderHour = '09'
    let reminderMinute = '00'
    let reminderSecond = '00'
    if (reminder?.reminderTime) {
      const reminderParts = reminder.reminderTime.split(' ')
      if (reminderParts.length > 1) {
        const timeParts = reminderParts[1].split(':')
        reminderHour = timeParts[0] || '09'
        reminderMinute = timeParts[1] || '00'
        reminderSecond = timeParts[2] || '00'
      }
    }

    form.value = {
      title: props.editTask.title,
      subTitle: props.editTask.subTitle,
      priority: props.editTask.priority,
      category: props.editTask.category,
      startDate: props.editTask.startDate || endDate,
      startHour: props.editTask.startTime?.split(':')[0] || '09',
      startMinute: props.editTask.startTime?.split(':')[1] || '00',
      startSecond: '00',
      endDate: endDate,
      endHour: endHour,
      endMinute: endMinute,
      tags: props.editTask.tags.join(', '),
      reminderEnabled: reminder?.enabled || false,
      reminderDate: reminder?.reminderTime ? reminder.reminderTime.split(' ')[0] : endDate,
      reminderHour: reminderHour,
      reminderMinute: reminderMinute,
      reminderSecond: reminderSecond
    }
  }
}

watch(() => props.visible, (visible) => {
  if (visible) {
    if (props.type === ModalType.CREATE) {
      resetForm()
    } else {
      loadEditData()
    }
  }
})

const handleClose = () => {
  emit('close')
}

const handleSave = () => {
  if (!form.value.title.trim()) {
    alert('请输入事务标题')
    return
  }
  if (!form.value.startDate || !form.value.endDate) {
    alert('请选择开始和结束日期')
    return
  }
  
  // 校验所有时间
  if (!isEndDateValid.value) {
    alert('结束日期不能早于开始日期')
    return
  }
  if (!isEndTimeValid.value) {
    alert('结束时间不能早于开始时间')
    return
  }
    if (form.value.reminderEnabled) {
    if (!isReminderDateValid.value) {
      alert('提醒时间必须满足：\n1. 不晚于开始时间\n2. 不早于开始时间前30天\n3. 不能是过去的时间')
      return
    }
    if (!isReminderTimeValid.value) {
      alert('提醒时间不能晚于开始时间，也不能是过去的时间')
      return
    }
  }

  // 构建提醒设置（包含秒）
  let reminder: Reminder | undefined = undefined
  if (form.value.reminderEnabled) {
    reminder = {
      enabled: true,
      reminderTime: `${form.value.reminderDate} ${form.value.reminderHour}:${form.value.reminderMinute}:${form.value.reminderSecond || '00'}`
    }
  }

  const endTimeStr = `${form.value.endHour}:${form.value.endMinute}`
  const task: Task = {
    id: props.editTask?.id || generateUUID(),
    title: form.value.title.trim(),
    subTitle: form.value.subTitle.trim(),
    priority: form.value.priority,
    category: form.value.category,
    startDate: form.value.startDate,
    startTime: `${form.value.startHour}:${form.value.startMinute}`,
    endTime: endTimeStr,
    deadline: `${form.value.endDate} ${endTimeStr}`,
    tags: form.value.tags
      .split(',')
      .map(t => t.trim())
      .filter(t => t),
    status: props.editTask?.status || TaskStatus.UNFINISHED,
    createTime: props.editTask?.createTime || formatDateTime(),
    reminder
  }

  emit('save', task)
}
</script>

<template>
  <div v-if="visible" class="modal-mask" @click.self="handleClose">
    <div class="modal-content slide-in-right">
      <div class="modal-header">
        <h2>{{ type === ModalType.CREATE ? '新建事务' : '编辑事务' }}</h2>
        <button class="close-btn" @click="handleClose">✕</button>
      </div>

      <div class="modal-body">
        <div class="form-group">
          <label>事务标题 <span class="required">*</span></label>
          <input
            v-model="form.title"
            type="text"
            class="input-normal"
            placeholder="请输入事务标题"
          />
        </div>

        <div class="form-group">
          <label>内容/详细</label>
          <textarea
            v-model="form.subTitle"
            class="input-normal"
            rows="2"
            placeholder="请输入详细描述（可选）"
          ></textarea>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>优先级</label>
            <select v-model="form.priority" class="input-normal">
              <option :value="Priority.HIGH">高</option>
              <option :value="Priority.MID">中</option>
              <option :value="Priority.LOW">低</option>
            </select>
          </div>

          <div class="form-group">
            <label>分类</label>
            <select v-model="form.category" class="input-normal">
              <option :value="Category.WORK">工作</option>
              <option :value="Category.PERSONAL">个人</option>
            </select>
          </div>
        </div>

        <!-- 开始时间 -->
        <div class="form-group datetime-group">
          <label>开始时间 <span class="required">*</span></label>
          <div class="datetime-row">
            <input
              v-model="form.startDate"
              type="date"
              class="input-normal date-input"
            />
            <div class="time-picker">
              <div class="time-scroll">
                <select v-model="form.startHour" class="time-select">
                  <option
                    v-for="h in hourOptions"
                    :key="h"
                    :value="h"
                  >{{ h }}</option>
                </select>
              </div>
              <span class="time-separator">:</span>
              <div class="time-scroll">
                <select v-model="form.startMinute" class="time-select">
                  <option
                    v-for="m in minuteOptions"
                    :key="m"
                    :value="m"
                  >{{ m }}</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <!-- 结束时间 -->
        <div class="form-group datetime-group">
          <label>结束时间 <span class="required">*</span></label>
          <div class="datetime-row">
            <input
              v-model="form.endDate"
              type="date"
              class="input-normal date-input"
              :class="{ 'invalid': !isEndDateValid }"
            />
            <div class="time-picker">
              <div class="time-scroll">
                <select v-model="form.endHour" class="time-select">
                  <option
                    v-for="h in hourOptions"
                    :key="h"
                    :value="h"
                    :class="{ 'disabled': !isEndHourSelectable(h) }"
                    :disabled="!isEndHourSelectable(h)"
                  >{{ h }}</option>
                </select>
              </div>
              <span class="time-separator">:</span>
              <div class="time-scroll">
                <select v-model="form.endMinute" class="time-select">
                  <option
                    v-for="m in minuteOptions"
                    :key="m"
                    :value="m"
                    :class="{ 'disabled': !isEndMinuteSelectable(m) }"
                    :disabled="!isEndMinuteSelectable(m)"
                  >{{ m }}</option>
                </select>
              </div>
            </div>
          </div>
          <p v-if="!isEndDateValid" class="error-text">结束日期不能早于开始日期</p>
          <p v-else-if="!isEndTimeValid" class="error-text">结束时间不能早于开始时间</p>
        </div>

        <div class="form-group">
          <label>自定义标签</label>
          <input
            v-model="form.tags"
            type="text"
            class="input-normal"
            placeholder="用逗号分隔多个标签，例如：重要,紧急"
          />
          <p class="form-hint">提示：多个标签请用英文逗号分隔</p>
        </div>

        <!-- 提醒设置 -->
        <div class="form-group reminder-section">
          <div class="reminder-header">
            <label class="reminder-title">
              <span class="reminder-icon">🔔</span>
              开启提醒
            </label>
            <label class="switch">
              <input 
                type="checkbox" 
                v-model="form.reminderEnabled"
              />
              <span class="slider"></span>
            </label>
          </div>
          
          <div v-if="form.reminderEnabled" class="reminder-content">
            <div class="datetime-row">
              <input
                v-model="form.reminderDate"
                type="date"
                class="input-normal date-input"
                :class="{ 'invalid': !isReminderDateValid }"
              />
              <div class="time-picker">
                <div class="time-scroll">
                  <select v-model="form.reminderHour" class="time-select">
                    <option
                      v-for="h in hourOptions"
                      :key="h"
                      :value="h"
                      :class="{ 'disabled': !isReminderHourSelectable(h) }"
                      :disabled="!isReminderHourSelectable(h)"
                    >{{ h }}</option>
                  </select>
                </div>
                <span class="time-separator">:</span>
                <div class="time-scroll">
                  <select v-model="form.reminderMinute" class="time-select">
                    <option
                      v-for="m in minuteOptions"
                      :key="m"
                      :value="m"
                      :class="{ 'disabled': !isReminderMinuteSelectable(m) }"
                      :disabled="!isReminderMinuteSelectable(m)"
                    >{{ m }}</option>
                  </select>
                </div>
              </div>
            </div>
            <p v-if="!isReminderDateValid" class="error-text">提醒时间必须：≤开始时间、≥开始时间前30天、且不能是过去时间</p>
            <p v-else-if="!isReminderTimeValid" class="error-text">提醒时间不能晚于开始时间，也不能是过去的时间</p>
            <p v-else class="reminder-hint">
              <span class="hint-icon">💡</span>
              将在 {{ form.reminderDate }} {{ form.reminderHour }}:{{ form.reminderMinute }} 提醒您
            </p>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn-cancel" @click="handleClose">取消</button>
        <button class="btn-save" @click="handleSave">
          {{ type === ModalType.CREATE ? '创建' : '保存' }}
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.modal-mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  border-radius: var(--radius-lg);
  padding: 24px;
  width: 90%;
  max-width: 560px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.modal-header h2 {
  font-size: 18px;
  color: var(--text-main);
  margin: 0;
}

.close-btn {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background-color: var(--bg-gray);
  color: var(--text-secondary);
  font-size: 18px;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-btn:hover {
  background-color: var(--expired);
  color: white;
}

.modal-body {
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 14px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}

.form-group label {
  display: block;
  font-size: 13px;
  color: var(--text-secondary);
  margin-bottom: 6px;
}

.required {
  color: var(--expired);
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text-main);
  font-size: 14px;
  background-color: white;
  transition: border-color 0.2s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  border-color: var(--primary);
  outline: none;
}

.form-group input.invalid {
  border-color: var(--expired);
  background-color: #fff2f0;
}

.form-hint {
  font-size: 12px;
  color: var(--text-placeholder);
  margin-top: 4px;
}

.error-text {
  font-size: 12px;
  color: var(--expired);
  margin-top: 4px;
}

/* 日期时间选择器 */
.datetime-group {
  background-color: #f8f9fa;
  padding: 12px;
  border-radius: 8px;
}

.datetime-row {
  display: flex;
  gap: 10px;
  align-items: center;
}

.date-input {
  flex: 1;
  min-width: 130px;
}

.time-picker {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1.5;
}

.time-scroll {
  flex: 1;
}

.time-select {
  width: 100%;
  padding: 10px 8px;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  font-size: 14px;
  background-color: white;
  cursor: pointer;
}

.time-select option {
  padding: 8px;
}

.time-select option.disabled {
  color: #ccc;
  background-color: #f5f5f5;
}

.time-separator {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-secondary);
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding-top: 16px;
  border-top: 1px solid var(--border);
}

.btn-cancel {
  padding: 8px 20px;
  background-color: white;
  color: var(--text-secondary);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  font-size: 14px;
  cursor: pointer;
}

.btn-cancel:hover {
  background-color: var(--bg-gray);
}

.btn-save {
  padding: 8px 20px;
  background-color: var(--primary);
  color: white;
  border: none;
  border-radius: var(--radius-sm);
  font-size: 14px;
  cursor: pointer;
}

.btn-save:hover {
  background-color: #0ea6e0;
}

/* 提醒设置样式 */
.reminder-section {
  background: linear-gradient(135deg, #fff9e6 0%, #fff5d6 100%);
  border: 1px solid #ffe4b3;
  border-radius: 12px;
  padding: 14px;
  margin-top: 16px;
}

.reminder-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.reminder-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 600;
  color: var(--text-main);
  margin: 0;
}

.reminder-icon {
  font-size: 16px;
}

/* 开关样式 */
.switch {
  position: relative;
  display: inline-block;
  width: 48px;
  height: 26px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: .3s;
  border-radius: 26px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 20px;
  width: 20px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: .3s;
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

input:checked + .slider {
  background: linear-gradient(135deg, #FF8C42 0%, #FF6B6B 100%);
}

input:checked + .slider:before {
  transform: translateX(22px);
}

.reminder-content {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px dashed #ffd699;
}

.reminder-hint {
  margin: 10px 0 0;
  padding: 8px 10px;
  background-color: rgba(255, 255, 255, 0.7);
  border-radius: 6px;
  font-size: 12px;
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  gap: 6px;
}

.hint-icon {
  font-size: 12px;
}

/* ========== 手机端适配 ========== */
@media (max-width: 768px) {
  .modal-content {
    width: 92%;
    max-width: none;
    max-height: 85vh;
    padding: 16px;
    border-radius: 12px;
  }

  .modal-header {
    margin-bottom: 16px;
  }

  .modal-header h2 {
    font-size: 16px;
  }

  .close-btn {
    width: 28px;
    height: 28px;
    font-size: 16px;
  }

  .form-group {
    margin-bottom: 12px;
  }

  .form-group label {
    font-size: 12px;
    margin-bottom: 4px;
  }

  .form-group input,
  .form-group select,
  .form-group textarea {
    padding: 8px 10px;
    font-size: 14px;
  }

  .form-row {
    gap: 10px;
  }

  /* 日期时间选择器手机端适配 */
  .datetime-group {
    padding: 10px;
  }

  .datetime-row {
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
  }

  .date-input {
    min-width: auto;
    width: 100%;
  }

  .time-picker {
    width: 100%;
    justify-content: center;
  }

  .time-select {
    padding: 8px 6px;
    font-size: 13px;
  }

  /* 按钮区域 */
  .modal-footer {
    flex-direction: column-reverse;
    gap: 10px;
    padding-top: 12px;
  }

  .btn-cancel,
  .btn-save {
    width: 100%;
    padding: 12px 20px;
    font-size: 15px;
  }

  /* 提醒设置 */
  .reminder-section {
    padding: 12px;
    margin-top: 12px;
  }

  .reminder-title {
    font-size: 13px;
  }

  .switch {
    width: 44px;
    height: 24px;
  }

  .slider:before {
    height: 18px;
    width: 18px;
    left: 3px;
    bottom: 3px;
  }

  input:checked + .slider:before {
    transform: translateX(20px);
  }
}

@media (max-width: 480px) {
  .modal-content {
    width: 95%;
    padding: 14px;
    max-height: 88vh;
  }

  .modal-header h2 {
    font-size: 15px;
  }

  .form-group input,
  .form-group select,
  .form-group textarea {
    padding: 10px 12px;
    font-size: 16px; /* 防止iOS缩放 */
  }

  .datetime-row {
    gap: 6px;
  }

  .time-picker {
    gap: 6px;
  }

  .time-select {
    font-size: 14px;
  }

  .btn-cancel,
  .btn-save {
    padding: 14px 20px;
    font-size: 16px;
  }
}
</style>
